# 円谷営業改革パッケージ — 収録物一覧（INDEX）

**作成者：円谷プロダクション 専務執行役員 新谷 隼人（本改革スポンサー）／管理：STO**
**作成日：2026-07-06｜取り扱い：社外秘**

> ファイル名・フォルダ名は、ZIP解凍時の文字化けを防ぐためすべて英数字にしています。
> 中身はすべて日本語です。下の対応表でファイル名と資料名を確認してください。
> **最初に `6_project_mgmt/playbook.md`（プロジェクト進行プレイブック）を読んでください。**

---

## ファイル名 ⇔ 資料名 対応表

### 1_management_deck（経営会議用｜STEP 0：Day 0）
| ファイル名 | 資料名・用途 |
|---|---|
| grand_design.pptx | **営業改革グランドデザイン**（経営会議付議用・全37枚） |
| grand_design_view.pdf | 同・PDF閲覧版（配布・タブレット用） |
| grand_design_detail.md | 同・詳細版原稿（全スライド原稿／90日計画／KPI定義／ダッシュボード設計の原典） |

### 2_member_briefing（現場説明用｜STEP 2：Day 3〜10）
| ファイル名 | 資料名・用途 |
|---|---|
| member_briefing.pptx | **営業改革 メンバー説明会資料**（15分説明会用・全15枚・FAQ11問）※スライド15のSTO窓口を実名化してから使用 |
| member_briefing_view.pdf | 同・PDF閲覧版（説明会後の配布用） |

### 3_excel_tools（運用Excel｜STEP 1〜8：Day 1から常用）
| ファイル名 | 資料名・用途 |
|---|---|
| 01_inventory_scoring_master.xlsx | **棚卸し・スコアリングマスター**（中核DB：5つの棚卸し＋7軸スコア自動計算＋顧客ランク自動判定＋停滞・トリアージ自動抽出）※使用前に「マスタ設定」シートの黄色セルを自社仕様に調整 |
| 02_worktime_weekly_template.xlsx | **工数申告 週次テンプレート**（1人1ファイル・週15分・自動集計付き） |
| 03_kpi_meeting_90day_wbs.xlsx | **KPI・会議運営・90日WBS**（15KPI管理／決定ログ／月次会議アジェンダ／90日タスク30件／外交逆提案リスト） |

### 4_templates（運用テンプレート｜STEP 2〜7）
| ファイル名 | 資料名・用途 |
|---|---|
| kickoff_message.md | **経営キックオフ宣言文案**（Day 3までに経営陣連名で全社発信。【 】を埋めて使用） |
| meeting_agenda_minutes.md | **会議アジェンダ・議事録テンプレート**（週次30分／月次90分／四半期＋トリアージ起案書の型） |
| top_diplomacy_48h_memo.md | **トップ外交48時間登録メモ**（経営陣用1分メモの型＋STO処理SLA） |

### 5_notion_kit（Notion構築キット｜STEP 5・9：Month 2〜）
| ファイル名 | 資料名・用途 |
|---|---|
| notion_setup_guide.md | **Notion構築ガイド**（9DB設計・数式・3層ダッシュボードビュー・権限。構築半日） |
| csv/customers.csv | 顧客DB（インポート雛形） |
| csv/deals.csv | 案件DB（中核） |
| csv/partners.csv | パートナーDB |
| csv/top_diplomacy.csv | トップ外交DB |
| csv/dormant_customers.csv | 休眠顧客DB |
| csv/worktime_log.csv | 工数ログDB |
| csv/decision_log.csv | 決定ログDB |
| csv/tasks_90days.csv | 90日タスクDB（30タスク入り） |
| csv/kpi.csv | KPI DB（15指標入り） |

※ NotionへのCSVインポート後、データベース名はファイル名（英語）になります。上表の日本語名（顧客DB等）にリネームしてから、構築ガイドのプロパティ設定に進んでください。

### 6_project_mgmt（進行管理｜全STEP）
| ファイル名 | 資料名・用途 |
|---|---|
| playbook.md | **プロジェクト進行プレイブック**（最初に読む。10ステップ×プロセス×使用資料×完了条件の地図） |
| operations_guide.md | **運用ガイド**（導入手順Day 1〜7／運用サイクル／RACI／運用ルール10か条） |

---

## 開封後にやること（3つだけ）

1. `01_inventory_scoring_master.xlsx` の「マスタ設定」シートで担当者リストを実名化（ウェイト・閾値はDay 31〜45の経営ワークショップ後に確定値へ更新）
2. `member_briefing.pptx` スライド15のSTO窓口を実名化
3. `kickoff_message.md` の【 】箇所（日付・連絡先）を記入

## 共通ルール（要点・詳細はoperations_guide.md）

- 工数データは人事評価に使わない（経営宣言に明記）
- スコアの閾値（S≥80／A≥65／B≥50、停滞30日、外交初動30日）はExcelとNotionで常に一致させる
- サンプル行（「（サンプル）」表記）は実データ投入後に削除する
- ファイルの中身（.md）はUTF-8です。文字化けする場合はメモ帳ではなくVS Code・ブラウザ等で開いてください

以上
