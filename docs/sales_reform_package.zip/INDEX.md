# 営業改革 一式パッケージ INDEX（2026-07-11版）

ZIP内はWindowsでの文字化け防止のため英数字ファイル名。下表で日本語名と対応。
最新版のみ収録（旧版デッキ2点＝グランドデザイン_円谷／メンバー説明会資料は未収録。リポジトリ参照）。

| ファイル | 日本語名 | 分類 | 用途 |
|---|---|---|---|
| A01_grand_design_full.md | 営業改革グランドデザイン本文 | A. 戦略 | グランドデザイン本文（8章・全設計の原典） |
| A02_grand_design_exec_deck.pptx | 営業改革グランドデザイン_経営幹部説明版 | A. 戦略 | 経営会議向け43枚（自己紹介6枚＋本編37枚） |
| B01_bucho_30min.pptx | 営業改革_部長会共有資料（30分版） | B. 説明資料 | 部長会30分・経営会議承認前版 |
| B02_bucho_meeting_ops.pptx | 営業改革_部長会共有資料_会議運用編 | B. 説明資料 | 会議体の回し方8枚（図解版） |
| B03_bucho_90min_full.pptx | 営業改革_部長会共有資料_90分完全版 | B. 説明資料 | 部長会90分・4部構成 |
| B04_allhands_45min.pptx | 営業改革_全社説明会資料 | B. 説明資料 | 全メンバー説明会45分 |
| B05_chairman_briefing.pptx | 営業改革_山本会長共有資料 | B. 説明資料 | 山本会長 事前共有MTG30分・8枚 |
| B06_chairman_sto_launch.pptx | 営業改革_STO立ち上げ_山本会長共有資料 | B. 説明資料 | 山本会長向けSTO立ち上げ説明12枚 |
| B07_bucho_progress_20260714.pptx | 営業改革_部長会進捗共有_20260714 | B. 説明資料 | 部長会向け進捗共有14枚（会長決議と全体進捗） |
| B08_ops_manual_deck.pptx | 営業改革_運用指南書_説明資料 | B. 説明資料 | 運用指南書のスライド版13枚（オンボーディング用） |
| C01_inventory_scoring_master.xlsx | 01_棚卸し・スコアリングマスター | C. 実行ツール | 5棚卸し＋採点定義（初期テンプレート。運用正本は坪井さん共有版） |
| C02_workload_weekly.xlsx | 02_工数申告_週次テンプレート | C. 実行ツール | 週次工数申告（評価に使わない） |
| C03_kpi_meetings_wbs.xlsx | 03_KPI・会議運営・90日WBS | C. 実行ツール | KPI体系・決定ログ・90日WBS |
| C04_feedback_replies.xlsx | フィードバック回答_新谷コメント | C. 実行ツール | 部長FB37件への回答（最終版） |
| C05_reply_paste_37lines.txt | コメント貼り付け用_37行 | C. 実行ツール | スプレッドシート転記用 |
| D01_playbook.md | 00_プロジェクト進行プレイブック | D. 運営 | 10 STEPの進行手順×必要資料 |
| D00_operations_manual.md | 運用指南書 | D. 運営 | 役割別の実務マニュアル（現場で最初に読む1冊） |
| D02_sto_design.md | STO設計書_体制と運用 | D. 運営 | STO4名体制の設計書 |
| D03_sto_letters.md | STO通知・依頼文テンプレート | D. 運営 | 専任化通知ほか6通 |
| D04_sto_org_deck.pptx | STO体制_説明資料 | D. 運営 | 体制図＋週次リズム2枚 |
| D05_sto_weekly_ops.xlsx | STO週次運用管理 | D. 運営 | 週次レビュー・宿題管理・エスカレーションログ・RACI |
| D06_meeting_design.md | 会議運用設計書 | D. 運営 | 会議体系の全体ルール |
| D07_meeting_agenda_detail.md | 会議体別アジェンダ詳細設計 | D. 運営 | 全7会議体の分単位アジェンダ・フェーズ別 |
| D08_agenda_bunkakai.docx | 分科会_アジェンダ議事テンプレート | D. 運営 | 分科会Word様式 |
| D09_agenda_senryaku.docx | 戦略会議_アジェンダ議事テンプレート | D. 運営 | 戦略会議Word様式 |
| D10_agenda_tenken.docx | 点検会議_アジェンダ議事録テンプレート | D. 運営 | 点検会議Word様式 |
| D11_pmo_daily_memo.docx | PMO会議_日次メモテンプレート | D. 運営 | STO日次会議メモ様式 |
| D12_tenken_keycharts.pptx | 点検会議_キーチャートテンプレート | D. 運営 | 点検会議PPT5枚型 |
| D13_workload_usage_design.md | 工数活用設計_提案と実行レベル | D. 運営 | 工数把握後の提案マップ・L1〜L4・Day1〜90 |
| D14_kickoff_declaration.md | 経営キックオフ宣言文案 | D. 運営 | 経営宣言の文案 |
| D15_agenda_minutes_md.md | 会議アジェンダ・議事録テンプレート | D. 運営 | 汎用md版 |
| D16_top_diplomacy_48h.md | トップ外交48時間登録メモ | D. 運営 | トップ面談後48時間記録様式 |
| E01_findata_basis_memo.md | データ基盤メモ_財務実数 | E. データ | 61〜65期の財務実数と設計反映 |
| E02_analysis_summary.md | 財務分析サマリー | E. データ | 財務分析の詳細（検算済み） |
| E03_sakuhin_rieki_all.csv | 作品利益明細（5期） | E. データ | 作品×期の明細338行 |
| E04_kibetsu_summary.csv | 期別サマリー | E. データ | 期別集計 |
| E07_fy26_forecast_memo.md | 66期通期見込みメモ | E. データ | 営業事業本部の当期着地見込み分析と改革への反映 |
| E05_gross_profit_memo.md | 粗利算定_他社分消去メモ | E. データ | 委員会配分構造と粗利算定の設計結論 |
| E06_nx_workflow_memo.md | NXワークフロー理解メモ | E. データ | NXのE2Eフローと改革への接続 |
| E08_kanshu_reform_memo.md | 監修改革_論点メモ | E. データ | 監修改革の論点整理（最重要ボトルネック） |
| D17_sto_minutes_20260714.md | STO定例メモ_20260714 | D. 運営 | STO定例の決定記録とタスク |
| F01_notion_guide.md | Notion構築ガイド | F. Notion | Notion化の構築手順 |
| F02_db_customers.csv | 顧客DB | F. Notion | 初期データ |
| F03_db_deals.csv | 案件DB | F. Notion | 初期データ |
| F04_db_partners.csv | パートナーDB | F. Notion | 初期データ |
| F05_db_top_diplomacy.csv | トップ外交DB | F. Notion | 初期データ |
| F06_db_dormant.csv | 休眠顧客DB | F. Notion | 初期データ |
| F07_db_workload.csv | 工数ログDB | F. Notion | 初期データ |
| F08_db_decisions.csv | 決定ログDB | F. Notion | 初期データ |
| F09_db_kpi.csv | KPIDB | F. Notion | 初期データ |
| F10_db_tasks90.csv | 90日タスクDB | F. Notion | 初期データ |
| G01_toolkit_readme.md | ツールキットREADME | G. 索引 | ツールキットの使い方 |
| G02_master_index.md | 資料一覧_最新版 | G. 索引 | 全資料の正本一覧（最新版の判定はこれを見る） |
